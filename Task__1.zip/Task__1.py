import tkinter as tk

def click(event):
    text = event.widget.cget("text")
    if text == "=":
        expr = screen.get()
        # Check for balanced parentheses
        if expr.count('(') != expr.count(')'):
            screen.set("Error: Unmatched ()")
            return
        try:
            result = str(eval(expr))
            history_listbox.insert(tk.END, f"{expr} = {result}")
            screen.set(result)
        except Exception:
            screen.set("Error")
    elif text == "C":
        screen.set("")
    elif text == "⌫":
        screen.set(screen.get()[:-1])
    else:
        screen.set(screen.get() + text)

def key_press(event):
    if event.char in "0123456789.+-*/()":
        screen.set(screen.get() + event.char)
    elif event.keysym == "Return":
        try:
            result = str(eval(screen.get()))
            history_listbox.insert(tk.END, f"{screen.get()} = {result}")
            screen.set(result)
        except Exception:
            screen.set("Error")
    elif event.keysym == "BackSpace":
        screen.set(screen.get()[:-1])
    elif event.keysym == "Escape":
        screen.set("")

root = tk.Tk()
root.title("Advanced Calculator")
root.geometry("350x500")

screen = tk.StringVar()
entry = tk.Entry(root, textvar=screen, font="Arial 20", bd=10, relief=tk.SUNKEN, justify='right')
entry.grid(row=0, column=0, columnspan=5, sticky="nsew", padx=10, pady=10)

button_texts = [
    ['7', '8', '9', '/', '('],
    ['4', '5', '6', '*', ')'],
    ['1', '2', '3', '-', '⌫'],
    ['0', '.', 'C', '+', '=']
]

for i, row in enumerate(button_texts):
    for j, btn_text in enumerate(row):
        btn = tk.Button(root, text=btn_text, font="Arial 18", height=2, width=5)
        btn.grid(row=i+1, column=j, sticky="nsew", padx=2, pady=2)
        btn.bind("<Button-1>", click)

# History Listbox
history_label = tk.Label(root, text="History", font="Arial 12 bold")
history_label.grid(row=5, column=0, columnspan=5, sticky="w", padx=10)
history_listbox = tk.Listbox(root, height=5, font="Arial 12")
history_listbox.grid(row=6, column=0, columnspan=5, sticky="nsew", padx=10, pady=5)

# Configure grid weights for resizing
for i in range(5):
    root.grid_columnconfigure(i, weight=1)
for i in range(7):
    root.grid_rowconfigure(i, weight=1)

root.bind("<Key>", key_press)

root.mainloop()